class Product:
    def __init__(self, product_id, name, price, stock):
        self.id = product_id 
        self.name = name 
        self.price = price 
        self.stock = stock 

    def to_dict(self):
        # Chuyển đổi sang dictionary để trả về JSON [cite: 36, 37]
        return {
            "id": self.id,
            "name": self.name,
            "price": self.price,
            "stock": self.stock
        } 