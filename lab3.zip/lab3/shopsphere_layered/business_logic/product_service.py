from persistence.product_repository import ProductRepository 

class ProductService:
    """Lớp xử lý quy tắc nghiệp vụ, xác thực và logic giao dịch[cite: 90]."""
    
    def __init__(self):
        self.repo = ProductRepository() 

    def create_product(self, name, price, stock):
        # Quy tắc: Tên không trống và giá phải > 0 
        if not name or price <= 0:
            raise ValueError("Dữ liệu sản phẩm không hợp lệ: Tên không được trống và giá phải dương.") 
        return self.repo.create(name, price, stock) 

    def get_all_products(self):
        return self.repo.find_all() 

    def get_product(self, product_id):
        product = self.repo.find_by_id(product_id) 
        if not product:
            raise ValueError(f"Sản phẩm với ID {product_id} không tồn tại.") 
        return product 