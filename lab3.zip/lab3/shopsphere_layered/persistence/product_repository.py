from business_logic.models import Product 

product_db = {} 
next_id = 1 

class ProductRepository:
    """Lớp xử lý trực tiếp các thao tác CRUD trên kho dữ liệu[cite: 55]."""
    
    def create(self, name, price, stock):
        global next_id
        product_id = str(next_id) 
        new_product = Product(product_id, name, price, stock) 
        product_db[product_id] = new_product 
        next_id += 1 
        return new_product 

    def find_all(self):
        return list(product_db.values()) 

    def find_by_id(self, product_id):
        return product_db.get(product_id) 