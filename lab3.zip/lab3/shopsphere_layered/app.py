from flask import Flask, request, jsonify 
from business_logic.product_service import ProductService 

app = Flask(__name__) 
product_service = ProductService() 

@app.route('/api/products', methods=['POST'])
def create_product():
    data = request.json 
    try:
        product = product_service.create_product(
            data.get('name'), data.get('price'), data.get('stock')
        ) 
        return jsonify(product.to_dict()), 201 
    except ValueError as e:
        return jsonify({"error": str(e)}), 400 

@app.route('/api/products', methods=['GET'])
def get_products():
    products = product_service.get_all_products() 
    return jsonify([p.to_dict() for p in products]), 200 

if __name__ == '__main__':
    app.run(debug=True)